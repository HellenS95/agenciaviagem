import ContatoForm from "../components/ContatoForm";
import Footer from "../components/Footer";

const Contato = () => {
  return (
    <div>
      <ContatoForm />;
      <Footer />
    </div>
  );
};

export default Contato;
