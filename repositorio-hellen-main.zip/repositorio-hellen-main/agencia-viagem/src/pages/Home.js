import Propaganda from "../components/Propaganda";
import Footer from "../components/Footer";

const Home = () => {
  return (
    <div>
      <Propaganda />
      <Footer />
    </div>
  );
};

export default Home;
