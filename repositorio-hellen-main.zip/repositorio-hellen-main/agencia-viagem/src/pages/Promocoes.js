import CardsDestino from "../components/CardsDestino";
import Footer from "../components/Footer";

const Promocoes = () => {
  return (
    <div>
      <CardsDestino />
      <Footer />
    </div>
  );
};

export default Promocoes;
