const CategoriasDestino = () => {
    return (<section className="containerCategorias">
        <div className="itemCategoria">
            <h2> AVENTURAS</h2>
        </div>
        <div className="itemCategoria">
            <h2> DESCONTOS </h2>
        </div>
        <div className="itemCategoria">
            <h2> CONFORTO  </h2>
        </div>
    </section>)
}

export default  CategoriasDestino;